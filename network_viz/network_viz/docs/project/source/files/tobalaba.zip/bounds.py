#
# Map crop bounds

W = -70.6634
S = -33.4561
E = -70.5654
N = -33.3968
